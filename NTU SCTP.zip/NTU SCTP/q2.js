/*
    Task 1: 
    - Declare an array that are going to be used to store patient's name.

    Task 2: 
    - Add code to add patient's name into the array declared in task 1.

    Task 3: 
    - Implement listPatient() function to print all patient's name stored in the array
*/


const Patientarray=[]

function addPatient(patientName){
    Patientarray.push(patientName)
}

document.getElementById("listpatient").innerHTML = JSON.stringify(Patientarray)


addPatient("John");
addPatient("Mary");
addPatient("Mark");

listPatient(); // This should list ["John", "Mary", "Mark"]