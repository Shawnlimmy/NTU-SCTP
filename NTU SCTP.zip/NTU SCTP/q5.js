
/*
    Task 1:
    - Link the file `external.js` to this file.
    - To test if the linking works, open q5-output.html using VScode's Live Server extension. It should print "Hello World!"
*/

import print from "./external.js"

console.log(print)

// Do n>ot change the code below
document.querySelector("#test").innerHTML = print();
